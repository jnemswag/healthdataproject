import pandas as pd
import matplotlib.pyplot as plt

DATA_PATH = "data"
OUTPUT_PATH = "output"

# ----- clinics -----
clinics = pd.read_csv(f"{DATA_PATH}/A.csv")
clinics = clinics[clinics["Site State Abbreviation"] == "UT"]

clinics["GEOID"] = clinics[
    "State and County Federal Information Processing Standard Code"
].astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(5)

clinic_counts = clinics.groupby("GEOID").size().reset_index(name="clinic_count")

# ----- life expectancy (ALL counties) -----
life = pd.read_csv(f"{DATA_PATH}/B.csv")
life["GEOID"] = life["STATE2KX"].astype(str).str.zfill(2) + life["CNTY2KX"].astype(str).str.zfill(3)

county_life = life.groupby("GEOID")["e(0)"].mean().reset_index(name="life_expectancy")

# ----- merge using life expectancy as master list -----
df = county_life.merge(clinic_counts, on="GEOID", how="left")

df["clinic_count"] = df["clinic_count"].fillna(0)
df["has_clinic"] = (df["clinic_count"] > 0).astype(int)

print("Counties:", len(df))
print("Zero clinic counties:", (df["clinic_count"] == 0).sum())

# ----- compute means -----
means = df.groupby("has_clinic")["life_expectancy"].mean()

labels = ["No Clinics", "Has Clinics"]
values = [means[0], means[1]]

# ----- plot -----
plt.figure(figsize=(6,5))
bars = plt.bar(labels, values)

plt.ylabel("Average Life Expectancy")
plt.title("Life Expectancy by Clinic Access (Utah Counties)")

for bar in bars:
    y = bar.get_height()
    plt.text(bar.get_x()+bar.get_width()/2, y+0.1, f"{y:.2f}", ha='center')

plt.tight_layout()
plt.savefig(f"{OUTPUT_PATH}/life_expectancy_by_access.png", dpi=200)
plt.show()

print("Saved to output/life_expectancy_by_access.png")
