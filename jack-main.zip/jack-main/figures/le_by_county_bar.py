import os
import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd

DATA_DIR = "data"
OUT_DIR = "output"
os.makedirs(OUT_DIR, exist_ok=True)

# ---------- Load life expectancy data ----------
life = pd.read_csv(f"{DATA_DIR}/B.csv")

life["GEOID"] = (
    life["STATE2KX"].astype(str).str.zfill(2) +
    life["CNTY2KX"].astype(str).str.zfill(3)
)

county_le = (
    life.groupby("GEOID")["e(0)"]
    .mean()
    .reset_index(name="life_expectancy")
)

# ---------- County names ----------
shp = os.path.join(DATA_DIR, "tl_2023_us_county", "tl_2023_us_county.shp")
gdf = gpd.read_file(shp)
ut = gdf[gdf["STATEFP"] == "49"][["GEOID", "NAME"]].copy()
ut["county_name"] = ut["NAME"] + " County"

df = ut.merge(county_le, on="GEOID", how="left")

# remove Daggett County
df = df[df["county_name"] != "Daggett County"]


# sort lowest → highest for visual scan
df = df.sort_values("life_expectancy", ascending=True)

# ---------- Plot ----------
fig, ax = plt.subplots(figsize=(8, 7))  # compressed height

bars = ax.barh(df["county_name"], df["life_expectancy"])

ax.set_xlabel("Life Expectancy (years)")
ax.set_title("Life Expectancy by County — Utah")

# add value labels at end of bars
for bar in bars:
    width = bar.get_width()
    ax.text(
        width + 0.1,                 # slight offset
        bar.get_y() + bar.get_height()/2,
        f"{width:.1f}",
        va='center',
        fontsize=9
    )

# tighten layout & remove extra whitespace
plt.tight_layout()

out_path = f"{OUT_DIR}/life_expectancy_by_county.png"
plt.savefig(out_path, dpi=200, bbox_inches="tight")
plt.show()

print("Saved:", out_path)
