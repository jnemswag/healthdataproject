import os, json
import numpy as np
import pandas as pd
import geopandas as gpd

DATA_DIR = "data"
OUT_DIR = "../site/assets"
os.makedirs(OUT_DIR, exist_ok=True)

# ----------------------------
# Helpers
# ----------------------------
def sanitize_records(obj):
    """Recursively convert NaN/Inf floats to None so json.dump writes valid JSON."""
    if isinstance(obj, dict):
        return {k: sanitize_records(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitize_records(v) for v in obj]
    if isinstance(obj, float):
        if np.isnan(obj) or np.isinf(obj):
            return None
    return obj

def print_section(title):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)

# ----------------------------
# Load authoritative Utah counties (GEOID mapping + geometry)
# ----------------------------
print_section("Loading TIGER county shapefile + filtering Utah")
shp = os.path.join(DATA_DIR, "tl_2023_us_county", "tl_2023_us_county.shp")
gdf = gpd.read_file(shp)
ut_geo = gdf[gdf["STATEFP"] == "49"][["GEOID", "NAME", "geometry"]].copy()
ut_geo["county_name"] = ut_geo["NAME"].astype(str).str.strip() + " County"

print("Utah counties:", len(ut_geo))
print("Example GEOIDs:", ut_geo["GEOID"].head().tolist())

# ----------------------------
# Clinics (A.csv)
# ----------------------------
print_section("Loading clinics (A.csv) + counting per county GEOID")
clinics = pd.read_csv(os.path.join(DATA_DIR, "A.csv"))
clinics = clinics[clinics["Site State Abbreviation"] == "UT"].copy()

clinics["GEOID"] = (
    clinics["State and County Federal Information Processing Standard Code"]
    .astype(str)
    .str.replace(r"\.0$", "", regex=True)
    .str.zfill(5)
)

clinic_counts = clinics.groupby("GEOID").size().reset_index(name="clinic_count")
print("Clinic rows (UT):", len(clinics))
print("Counties with >=1 clinic:", (clinic_counts["clinic_count"] > 0).sum())

# ----------------------------
# Life expectancy (B.csv)
# ----------------------------
print_section("Loading life expectancy (B.csv) + averaging e(0) by GEOID")
life = pd.read_csv(os.path.join(DATA_DIR, "B.csv"))

life["GEOID"] = (
    life["STATE2KX"].astype(str).str.zfill(2) +
    life["CNTY2KX"].astype(str).str.zfill(3)
)

# Make sure e(0) is numeric
life["e(0)"] = pd.to_numeric(life["e(0)"], errors="coerce")
county_life = life.groupby("GEOID")["e(0)"].mean().reset_index(name="life_expectancy")

print("Life rows:", len(life))
print("Counties with life data:", county_life["life_expectancy"].notna().sum())

# ----------------------------
# Population (population.csv)
# ----------------------------
print_section("Loading population.csv + extracting Utah counties + 2024 population")
pop_raw = pd.read_csv(os.path.join(DATA_DIR, "population.csv"), header=3)
pop_raw.columns = [str(c).strip() for c in pop_raw.columns]

geo_col = "Unnamed: 0"
pop2024_col = "2024.0"

if geo_col not in pop_raw.columns:
    raise KeyError(f"Expected column '{geo_col}' not found. Columns: {pop_raw.columns.tolist()[:25]}")
if pop2024_col not in pop_raw.columns:
    raise KeyError(f"Expected column '{pop2024_col}' not found. Columns: {pop_raw.columns.tolist()[:25]}")

pop = pop_raw[pop_raw[geo_col].astype(str).str.contains("County", na=False)].copy()

pop["county_name"] = (
    pop[geo_col].astype(str)
    .str.strip()
    .str.lstrip(".")
    .str.replace(", Utah", "", regex=False)
)

pop = pop[["county_name", pop2024_col]].rename(columns={pop2024_col: "population_2024"})
pop["population_2024"] = pd.to_numeric(pop["population_2024"], errors="coerce")

print("Population county rows:", len(pop))
print("Population missing values:", pop["population_2024"].isna().sum())
print("Example population rows:\n", pop.head(8).to_string(index=False))

# ----------------------------
# Merge everything
# ----------------------------
print_section("Merging metrics onto authoritative Utah county GEOIDs")
df = ut_geo[["GEOID", "county_name"]].merge(pop, on="county_name", how="left")
df = df.merge(county_life, on="GEOID", how="left")
df = df.merge(clinic_counts, on="GEOID", how="left")

df["clinic_count"] = df["clinic_count"].fillna(0).astype(int)
df["has_clinic"] = (df["clinic_count"] > 0).astype(int)

# Compute clinics per 10k safely
df["clinics_per_10k"] = np.where(
    df["population_2024"].notna() & (df["population_2024"] > 0),
    df["clinic_count"] / df["population_2024"] * 10_000,
    np.nan
)

# Diagnostics for missing joins
missing_pop = df[df["population_2024"].isna()][["GEOID", "county_name"]]
missing_life = df[df["life_expectancy"].isna()][["GEOID", "county_name"]]

print("Missing population counties:", len(missing_pop))
if len(missing_pop):
    print(missing_pop.to_string(index=False))

print("Missing life expectancy counties:", len(missing_life))
if len(missing_life):
    print(missing_life.to_string(index=False))

# ----------------------------
# Write county_metrics.json (JSON-safe)
# ----------------------------
print_section("Writing county_metrics.json (valid JSON, no NaN)")
records = df[[
    "GEOID", "county_name", "population_2024",
    "clinic_count", "has_clinic", "clinics_per_10k", "life_expectancy"
]].to_dict(orient="records")

records = sanitize_records(records)

out_metrics = os.path.join(OUT_DIR, "county_metrics.json")
with open(out_metrics, "w") as f:
    json.dump(records, f, indent=2, allow_nan=False)

print("Wrote", out_metrics)

# ----------------------------
# Write ut_counties.geojson (simplified)
# ----------------------------
print_section("Writing ut_counties.geojson (simplified geometry)")
ut_out = ut_geo[["GEOID", "NAME", "geometry"]].copy()

# simplify for web performance (tweak tolerance if needed)
ut_out["geometry"] = ut_out["geometry"].simplify(tolerance=0.01, preserve_topology=True)

out_geo = os.path.join(OUT_DIR, "ut_counties.geojson")
ut_out.to_file(out_geo, driver="GeoJSON")
print("Wrote", out_geo)

print_section("Done")
