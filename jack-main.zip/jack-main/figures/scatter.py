import os
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR = "data"
OUT_DIR = "output"
os.makedirs(OUT_DIR, exist_ok=True)

clinics = pd.read_csv(f"{DATA_DIR}/A.csv")
life = pd.read_csv(f"{DATA_DIR}/B.csv")

# ---------- CLINIC COUNTS ----------
clinics = clinics[clinics["Site State Abbreviation"] == "UT"]

clinics["GEOID"] = clinics[
    "State and County Federal Information Processing Standard Code"
].astype(str).str.zfill(5)

clinic_counts = (
    clinics.groupby("GEOID")
    .size()
    .reset_index(name="clinic_count")
)

# ---------- COUNTY LIFE EXPECTANCY ----------
# county GEOID = state(2) + county(3)
life["GEOID"] = life["STATE2KX"].astype(str).str.zfill(2) + \
                life["CNTY2KX"].astype(str).str.zfill(3)

county_life = (
    life.groupby("GEOID")["e(0)"]
    .mean()
    .reset_index(name="life_expectancy")
)

# ---------- MERGE ----------
df = pd.merge(county_life, clinic_counts, on="GEOID", how="inner")

print("\nMerged data:")
print(df)

# ---------- CORRELATION ----------
corr = df["clinic_count"].corr(df["life_expectancy"])
print("\nCorrelation:", round(corr, 3))

# ---------- SCATTER PLOT ----------
plt.figure(figsize=(7,5))
plt.scatter(df["clinic_count"], df["life_expectancy"])

plt.xlabel("Number of Clinics")
plt.ylabel("Life Expectancy")
plt.title("Life Expectancy vs Clinics (Utah Counties)")

# add regression line
m, b = pd.Series(df["clinic_count"]).cov(df["life_expectancy"]) / df["clinic_count"].var(), \
       df["life_expectancy"].mean() - (pd.Series(df["clinic_count"]).cov(df["life_expectancy"]) / df["clinic_count"].var()) * df["clinic_count"].mean()

plt.plot(df["clinic_count"], m*df["clinic_count"] + b)

plt.savefig(f"{OUT_DIR}/scatter_life_vs_clinics.png", dpi=200)
plt.show()
