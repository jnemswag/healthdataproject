# scatter_allcounties.py
# Association-only analysis: include ALL Utah counties (including those with 0 clinics).
# Inputs:
#   data/A.csv  (HRSA FQHC sites)
#   data/B.csv  (USALEEP tract life expectancy)
#   data/population.csv (Utah county population; converted from co-est2024-pop-49.xlsx)
# Outputs:
#   output/scatter_life_vs_clinics_per_10k_allcounties.png

import os
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR = "data"
OUT_DIR = "output"
os.makedirs(OUT_DIR, exist_ok=True)

# ---------- Load inputs ----------
clinics = pd.read_csv(f"{DATA_DIR}/A.csv")
life = pd.read_csv(f"{DATA_DIR}/B.csv")
pop_raw = pd.read_csv(f"{DATA_DIR}/population.csv", header=3)  # real header starts on row 4

# ---------- Clinics: county counts ----------
clinics = clinics[clinics["Site State Abbreviation"] == "UT"].copy()

clinics["GEOID"] = clinics[
    "State and County Federal Information Processing Standard Code"
].astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(5)

clinic_counts = clinics.groupby("GEOID").size().reset_index(name="clinic_count")

# County name map (from clinic data, for joining/labeling)
county_name_map = (
    clinics[["GEOID", "Complete County Name"]]
    .drop_duplicates()
    .assign(**{"Complete County Name": lambda d: d["Complete County Name"].astype(str).str.strip()})
)

# ---------- Life expectancy: tract -> county ----------
life["GEOID"] = (
    life["STATE2KX"].astype(str).str.zfill(2)
    + life["CNTY2KX"].astype(str).str.zfill(3)
)

county_life = life.groupby("GEOID")["e(0)"].mean().reset_index(name="life_expectancy")

# ---------- Population: clean (ALL counties) + attach GEOID ----------
pop_raw.columns = [str(c).strip() for c in pop_raw.columns]

geo_col = "Unnamed: 0"
pop2024_col = "2024.0"

# Keep only county rows (exclude the Utah state total row)
pop = pop_raw[pop_raw[geo_col].astype(str).str.contains("County", na=False)].copy()

# Clean: ".Beaver County, Utah" -> "Beaver County"
pop["Complete County Name"] = (
    pop[geo_col].astype(str)
    .str.strip()
    .str.lstrip(".")
    .str.replace(", Utah", "", regex=False)
)

pop = pop[["Complete County Name", pop2024_col]].rename(columns={pop2024_col: "population_2024"})

# Attach GEOID by joining to clinic-derived county_name_map where possible,
# then fill remaining GEOIDs via a hard join on name using TIGER-like naming (still name-based).
# Best: use a full GEOID source; but for your current dataset, this works and we keep all counties
# by merging with a GEOID list from the USALEEP file too.

# GEOID list for all counties present in life expectancy file (should cover all 29)
life_county_geoid = (
    life[["STATE2KX", "CNTY2KX"]]
    .drop_duplicates()
    .assign(GEOID=lambda d: d["STATE2KX"].astype(str).str.zfill(2) + d["CNTY2KX"].astype(str).str.zfill(3))
    [["GEOID"]]
    .drop_duplicates()
)

# Build a GEOID->county-name table from clinics where available
# and from population where needed, we’ll just keep population as the master and merge GEOIDs later.
pop = pop.merge(county_name_map, on="Complete County Name", how="left")

# For counties with 0 clinics, GEOID will be missing. Fill GEOIDs by using the county_life GEOIDs
# plus a county-name lookup built from the TIGER county shapefile would be ideal, but you already
# have TIGER in data/ from earlier steps; we can read it if present to map name->GEOID.
# We'll do that to get ALL 29 reliably.

tiger_dir = os.path.join(DATA_DIR, "tl_2023_us_county")
tiger_shp = os.path.join(tiger_dir, "tl_2023_us_county.shp")

name_to_geoid = None
if os.path.exists(tiger_shp):
    import geopandas as gpd
    tiger = gpd.read_file(tiger_shp)
    ut = tiger[tiger["STATEFP"] == "49"][["GEOID", "NAME"]].copy()
    ut["Complete County Name"] = ut["NAME"].astype(str).str.strip() + " County"
    name_to_geoid = ut[["Complete County Name", "GEOID"]]
else:
    # Fallback: cannot reliably map county name -> GEOID for zero-clinic counties without a GEOID source
    # In practice, your data dir likely has TIGER already.
    name_to_geoid = None

if name_to_geoid is None:
    raise FileNotFoundError(
        "Missing TIGER county shapefile needed to map all county names to GEOIDs.\n"
        "Expected: data/tl_2023_us_county/tl_2023_us_county.shp\n"
        "You already downloaded this earlier for the heatmap; ensure it exists."
    )

# Fill GEOIDs for all counties using TIGER mapping
pop = pop.drop(columns=["GEOID"]).merge(name_to_geoid, on="Complete County Name", how="left")

# Sanity: should be 29 counties with GEOID
missing_geoid = pop["GEOID"].isna().sum()
if missing_geoid:
    raise ValueError(f"Could not map GEOID for {missing_geoid} counties. Check population county names vs TIGER names.")

print("Counties in population file:", len(pop))  # should be 29

# ---------- Merge EVERYTHING starting from ALL counties ----------
df = pop[["GEOID", "Complete County Name", "population_2024"]].copy()

df = df.merge(county_life, on="GEOID", how="left")
df = df.merge(clinic_counts, on="GEOID", how="left")

df["clinic_count"] = df["clinic_count"].fillna(0).astype(int)
df["has_clinic"] = (df["clinic_count"] > 0).astype(int)
df["clinics_per_10k"] = df["clinic_count"] / df["population_2024"] * 10_000

print("Total counties in analysis:", len(df))  # should be 29
print("Counties with zero clinics:", int((df["clinic_count"] == 0).sum()))

# ---------- Correlations (association only) ----------
corr_raw = df["clinic_count"].corr(df["life_expectancy"])
corr_pc = df["clinics_per_10k"].corr(df["life_expectancy"])
print("\nCorrelation (raw count vs life expectancy):", round(corr_raw, 3))
print("Correlation (clinics per 10k vs life expectancy):", round(corr_pc, 3))

print("\nMean life expectancy by has_clinic (0=no clinic, 1=has clinic):")
print(df.groupby("has_clinic")["life_expectancy"].mean())

# ---------- Scatter plot (include zero-clinic counties) ----------
plt.figure(figsize=(7, 5))

# Tiny jitter for zero values so points aren't perfectly stacked on x=0
x = df["clinics_per_10k"].copy()
x = x + (df["clinics_per_10k"] == 0) * 0.02

plt.scatter(x, df["life_expectancy"])
plt.xlabel("Clinics per 10,000 residents (2024)")
plt.ylabel("Life expectancy (county mean of tract e(0))")
plt.title("Life Expectancy vs Clinics per 10k (All Utah Counties)")

# regression line (association)
x2 = df["clinics_per_10k"]
y2 = df["life_expectancy"]
m = x2.cov(y2) / x2.var()
b = y2.mean() - m * x2.mean()
plt.plot(x2, m * x2 + b)

out_path = f"{OUT_DIR}/scatter_life_vs_clinics_per_10k_allcounties.png"
plt.tight_layout()
plt.savefig(out_path, dpi=200)
plt.show()

print("\nSaved:", out_path)
