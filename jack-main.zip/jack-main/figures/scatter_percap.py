# scatter_percap.py
import os
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR = "data"
OUT_DIR = "output"
os.makedirs(OUT_DIR, exist_ok=True)

# ---------- Load inputs ----------
clinics = pd.read_csv(f"{DATA_DIR}/A.csv")
life = pd.read_csv(f"{DATA_DIR}/B.csv")
pop = pd.read_csv(f"{DATA_DIR}/population.csv", header=3)  # real header starts on row 4

# ---------- Clinics: county counts ----------
clinics = clinics[clinics["Site State Abbreviation"] == "UT"].copy()

clinics["GEOID"] = clinics[
    "State and County Federal Information Processing Standard Code"
].astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(5)

clinic_counts = clinics.groupby("GEOID").size().reset_index(name="clinic_count")

# ---------- Life expectancy: tract -> county ----------
life["GEOID"] = (
    life["STATE2KX"].astype(str).str.zfill(2)
    + life["CNTY2KX"].astype(str).str.zfill(3)
)

county_life = life.groupby("GEOID")["e(0)"].mean().reset_index(name="life_expectancy")

# ---------- Population: clean + attach GEOID ----------
pop.columns = [str(c).strip() for c in pop.columns]

geo_col = "Unnamed: 0"
pop2024_col = "2024.0"

# Keep only rows containing "County" (exclude the Utah state total row)
pop = pop[pop[geo_col].astype(str).str.contains("County", na=False)].copy()

# Clean: ".Beaver County, Utah" -> "Beaver County"
pop["Complete County Name"] = (
    pop[geo_col].astype(str)
    .str.strip()
    .str.lstrip(".")
    .str.replace(", Utah", "", regex=False)
)

pop = pop[["Complete County Name", pop2024_col]].rename(columns={pop2024_col: "population_2024"})

# Map county name -> GEOID from clinic data
county_name_map = (
    clinics[["GEOID", "Complete County Name"]]
    .drop_duplicates()
    .assign(**{"Complete County Name": lambda d: d["Complete County Name"].str.strip()})
)

pop = pop.merge(county_name_map, on="Complete County Name", how="inner")

print("Population counties matched:", len(pop))  # should be 29 if everything matches

# ---------- Merge everything ----------
df = (
    county_life.merge(clinic_counts, on="GEOID", how="inner")
    .merge(pop[["GEOID", "population_2024", "Complete County Name"]], on="GEOID", how="inner")
)

df["clinics_per_10k"] = df["clinic_count"] / df["population_2024"] * 10_000

# ---------- Print quick stats ----------
print("\nTop 10 counties by clinics_per_10k:")
print(
    df.sort_values("clinics_per_10k", ascending=False)[
        ["Complete County Name", "clinic_count", "population_2024", "clinics_per_10k", "life_expectancy"]
    ].head(10).to_string(index=False)
)

corr_raw = df["clinic_count"].corr(df["life_expectancy"])
corr_pc = df["clinics_per_10k"].corr(df["life_expectancy"])
print("\nCorrelation (raw count vs life expectancy):", round(corr_raw, 3))
print("Correlation (clinics per 10k vs life expectancy):", round(corr_pc, 3))

df_no_outlier = df[df["population_2024"] > 5000]
print("Correlation (per capita, no tiny counties):",
      df_no_outlier["clinics_per_10k"].corr(df_no_outlier["life_expectancy"]))

# ---------- Scatter plot ----------
plt.figure(figsize=(7, 5))
plt.scatter(df["clinics_per_10k"], df["life_expectancy"])

plt.xlabel("Clinics per 10,000 residents (2024)")
plt.ylabel("Life expectancy (county mean of tract e(0))")
plt.title("Life Expectancy vs Clinics per 10k (Utah Counties)")

# Simple regression line
x = df["clinics_per_10k"]
y = df["life_expectancy"]
m = x.cov(y) / x.var()
b = y.mean() - m * x.mean()
plt.plot(x, m * x + b)

out_path = f"{OUT_DIR}/scatter_life_vs_clinics_per_10k.png"
plt.tight_layout()
plt.savefig(out_path, dpi=200)
plt.show()
print("\nSaved:", out_path)
