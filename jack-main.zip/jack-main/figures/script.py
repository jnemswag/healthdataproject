import os
import zipfile
import requests
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
OUT_DIR = os.path.join(PROJECT_ROOT, "output")
os.makedirs(OUT_DIR, exist_ok=True)

CLINICS_CSV = os.path.join(DATA_DIR, "A.csv")

# TIGER counties (national) – we'll filter to Utah
TIGER_YEAR = "2023"
TIGER_ZIP_URL = f"https://www2.census.gov/geo/tiger/TIGER{TIGER_YEAR}/COUNTY/tl_{TIGER_YEAR}_us_county.zip"
TIGER_ZIP_PATH = os.path.join(DATA_DIR, f"tl_{TIGER_YEAR}_us_county.zip")
TIGER_EXTRACT_DIR = os.path.join(DATA_DIR, f"tl_{TIGER_YEAR}_us_county")
TIGER_SHP_PATH = os.path.join(TIGER_EXTRACT_DIR, f"tl_{TIGER_YEAR}_us_county.shp")

PNG_OUT = os.path.join(OUT_DIR, "utah_clinics_per_county.png")
HTML_OUT = os.path.join(OUT_DIR, "utah_clinics_per_county.html")


def download_if_missing(url: str, dest_path: str) -> None:
    if os.path.exists(dest_path):
        return
    print(f"Downloading: {url}")
    r = requests.get(url, stream=True, timeout=60)
    r.raise_for_status()
    with open(dest_path, "wb") as f:
        for chunk in r.iter_content(chunk_size=1024 * 1024):
            if chunk:
                f.write(chunk)
    print(f"Saved to: {dest_path}")


def unzip_if_missing(zip_path: str, extract_dir: str) -> None:
    if os.path.exists(extract_dir) and any(name.endswith(".shp") for name in os.listdir(extract_dir)):
        return
    os.makedirs(extract_dir, exist_ok=True)
    print(f"Unzipping: {zip_path} -> {extract_dir}")
    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(extract_dir)


def main():
    # 1) Load clinics
    clinics = pd.read_csv(CLINICS_CSV)

    # Keep Utah-only (safe even if file is already Utah-only)
    if "Site State Abbreviation" in clinics.columns:
        clinics = clinics[clinics["Site State Abbreviation"] == "UT"].copy()

    # 2) Build county GEOID (state+county FIPS)
    # Prefer "State and County Federal Information Processing Standard Code" (e.g., 49055)
    fips_col = None
    for c in clinics.columns:
        if "State and County" in c and "Federal Information Processing" in c:
            fips_col = c
            break
    if fips_col is None:
        raise ValueError(
            "Could not find the county FIPS column in A.csv. "
            "Expected something like 'State and County Federal Information Processing Standard Code'."
        )

    clinics["GEOID"] = clinics[fips_col].astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(5)

    # Optional: keep a county display name (nice for debugging)
    county_name_col = "Complete County Name" if "Complete County Name" in clinics.columns else None

    # 3) Aggregate clinic counts per county
    if county_name_col:
        counts = (
            clinics.groupby(["GEOID", county_name_col])
            .size()
            .reset_index(name="clinic_count")
        )
    else:
        counts = clinics.groupby("GEOID").size().reset_index(name="clinic_count")

    # 4) Get county boundaries (auto-download TIGER if missing)
    download_if_missing(TIGER_ZIP_URL, TIGER_ZIP_PATH)
    unzip_if_missing(TIGER_ZIP_PATH, TIGER_EXTRACT_DIR)

    counties = gpd.read_file(TIGER_SHP_PATH)

    # Filter to Utah
    ut = counties[counties["STATEFP"] == "49"].copy()

    # TIGER counties already have GEOID
    ut["GEOID"] = ut["GEOID"].astype(str).str.zfill(5)

    # 5) Merge counts into geometry
    merged = ut.merge(counts[["GEOID", "clinic_count"]], on="GEOID", how="left")
    merged["clinic_count"] = merged["clinic_count"].fillna(0).astype(int)

    # 6) Plot choropleth PNG
    ax = merged.plot(
        column="clinic_count",
        legend=True,
        edgecolor="black",
        linewidth=0.7
    )
    ax.set_title("Clinics per County (Utah)")
    ax.axis("off")
    plt.tight_layout()
    plt.savefig(PNG_OUT, dpi=200)
    print(f"Saved PNG: {PNG_OUT}")

    # 7) Optional: interactive HTML (Folium)
    try:
        import folium

        m = folium.Map(location=[39.3, -111.7], zoom_start=6)

        folium.Choropleth(
            geo_data=merged.to_json(),
            data=merged,
            columns=["GEOID", "clinic_count"],
            key_on="feature.properties.GEOID",
            fill_color="YlOrRd",
            legend_name="Clinics per County"
        ).add_to(m)

        m.save(HTML_OUT)
        print(f"Saved HTML: {HTML_OUT}")
    except Exception as e:
        print(f"Skipped HTML map (folium error): {e}")


if __name__ == "__main__":
    main()
